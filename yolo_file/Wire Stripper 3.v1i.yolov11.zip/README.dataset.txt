# Wire Stripper 3 > 2026-09-14 11:03am
https://universe.roboflow.com/-r9dka/wire-stripper-3-3c0cm

Provided by a Roboflow user
License: CC BY 4.0

